package com.devtiro.tasks.domain.entities;

public enum TaskPriority {
    HIGH, MEDIUM, LOW
}
