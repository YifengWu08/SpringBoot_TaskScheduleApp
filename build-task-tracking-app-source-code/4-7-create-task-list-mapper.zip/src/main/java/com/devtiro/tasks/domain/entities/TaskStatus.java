package com.devtiro.tasks.domain.entities;

public enum TaskStatus {
    OPEN, CLOSED
}
